


-------------------------------------

App Name:		ParentWise
App Version:	1.0
Package:		com.shaikh.parentwise

-------------------------------------



-
-------------------------------------

